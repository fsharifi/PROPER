Before running the codes, please first run "mexC" to mex the related C functions.

The functions are given in the folder SLEP-functions.

