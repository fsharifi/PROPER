function Visualization3D(M,TRIPLE)
DIM=size(M.T);
Ntm=DIM(2);
for i=1:Ntm
CUTOFF(:,i)=(0.01:0.01:1);
end
M.CUTOFF=CUTOFF;
[n,~]=size(TRIPLE);
m2=ceil(sqrt(n-1))-1;
m1=ceil(sqrt(n-1));
if m1*m2<n-1
m2=m2+1;
end
Colors={'b', 'g' ,'r' ,'c', 'm' ,'y'} ;
figure('units','normalized','outerposition',[0 0 1 1]) 
Legend=cell(Ntm,1);
 for iter=1:Ntm
   Legend{iter}=strcat('Model', num2str(iter));
 end
for i=1:m1
for j=1:m2
k= (m2*(i-1)+j);
if k<n
subplot(m1,m2,k)
for e=1:Ntm
    c=mod(e+k,6)+1;
plot3(M.(TRIPLE{k+1,1})(:,e),M.(TRIPLE{k+1,2})(:,e),M.(TRIPLE{k+1,3})(:,e),Colors{c});
xlabel(TRIPLE{k+1,1});
ylabel(TRIPLE{k+1,2});
zlabel(TRIPLE{k+1,3});
hold on;
end
legend(Legend)
end
end
end
