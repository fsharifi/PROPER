%
% In this file, we mex the C files used in this package.

clear, clc;
current_path=cd;

cd SLEP;

fprintf('\n ----------------------------------------------------------------------------');
fprintf('\n This program is mexing the C files. Please wait...');
fprintf('\n If you have problem with mex, you can refer to the help of Matlab.');
fprintf('\n If you cannot solve the problem, please contact with Jun Liu (j.liu@asu.edu)');

% currently, this package use the following three C files
mex eplb.c;
mex eppVector.c;
mex eppMatrix.c;

fprintf('\n\n The C files eplb.c, eppVector.c and eppMatrix.c have been successfully mexed.');
fprintf('\n\n You can now use the functions in the folder SLL.');
fprintf('\n You are suggested to read the mannual for better using the codes.');
fprintf('\n You are also suggested to run the examples for these functions.');
fprintf('\n\n These codes are developed by Jun Liu and Jieping Ye at Arizona State University.');
fprintf('\n If there is any problem, please contact with Jun Liu (j.liu@asu.edu).');
fprintf('\n                               Thanks!                                       ');
fprintf('\n ----------------------------------------------------------------------------');

cd(current_path);