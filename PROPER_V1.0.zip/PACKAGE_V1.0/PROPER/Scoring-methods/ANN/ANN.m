function [P,Net]=ANN(XTRAIN,ytrain,XTEST,I,param,k,g)
[~,G]=size(g);
[~,K]=size(k);
[~,N]=size(XTRAIN);
NN=0;
for l=1:G;
for i=1:K;
    net = newff(minmax(XTRAIN'),[N k(i) 1],{'purelin' 'logsig' 'logsig'},g{l});
    net.trainParam.epochs = I;
    net.trainParam.show = 50;
    net.trainParam.goal = 0.001;
    net.trainParam.min_grad = 1e-050;
    net.trainParam.time = inf;
    net.trainParam.lr = param;
    [net, tr] = train(net, XTRAIN' ,ytrain');
    % Testing the Neural Network
    outtset = sim(net, XTEST');
    NN=NN+1;
    P(:,NN)=outtset';
    Net.(sprintf('N%d',NN))=net;
end
end
