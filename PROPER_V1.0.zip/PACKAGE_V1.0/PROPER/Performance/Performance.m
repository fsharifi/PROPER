function M=Performance(P,Labels)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% Normalization  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Normalizing classifiers predicted values into a range of 0-1.
% - P: values predicted by classifiers
% - NormP: Normalized Predicted values
% - Ntm: Number of trained models
% - n: Number of test samples
% - M: Structure including all calculater performance measures for each
%   single cutoff
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[n,Ntm]=size(P);

if n ~= length(Labels)
disp(' Error: Number of Rows in Labels and P should be equal')
M={};
return;
end

NormP=zeros(Ntm,n);

for i=1:Ntm;
for j=1:n;
NormP(i,j)=(P(j,i)-min(P(:,i)))/(max(P(:,i))-min(P(:,i)));
end
end
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% Cut-offs and Indices Calculation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - Cutoff: 100 values between 0 and 1 in steps of 0.1
% - Labels: real classes of samples
% - TP: number of true positives
% - FN: number of false negatives
% - FP: number of false positives
% - TN: number of true negatives
% - Ntm: number of trained models
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Cutoff=(0.01:0.01:1);
TP=zeros(100,Ntm);   TN=zeros(100,Ntm);     FP=zeros(100,Ntm);     FN=zeros(100,Ntm);

for k=1:Ntm;
for i=1:100;
for j=1:n;
if (Labels(j)==1)&&(NormP(k,j)>=Cutoff(i));
    TP(i,k)=TP(i,k)+1;
else if (Labels(j)==1)&&(NormP(k,j)<Cutoff(i));
        FN(i,k)=FN(i,k)+1;
    else if (Labels(j)==0)&&(NormP(j)>=Cutoff(i));
            FP(i,k)=FP(i,k)+1;
        else
            TN(i,k)=TN(i,k)+1;
        end
    end
end
end
end
end

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% Calculation of Performance Measures %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         T: number of true predictions
%         F: number of false predictions
%         RPP: rate of positive prediction              
%         RNP: rate of negative predictions
%         ACC: accuracy of predictor
%         TPR: true positive rate, sensitivity, or recall
%         FNR: false negative rate, miss
%         FPR: false positive rate, fallout
%         TNR: true negative rate or specificity
%         PPV: positive predictive value, precision
%         NPV: negative predictive value
%         MCC: Matthew Correlation Coefficient
%         FM: F Measure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

M.T     = [];      M.F     = [];     M.TPR   = [];      M.FNR   = []; 
M.FPR   = [];      M.TNR   = [];     M.PPV   = [];      M.NPV   = [];            
M.RPP   = [];      M.RNP   = [];     M.ACC   = [];      M.MCC   = [];
M.FM=[];

for j=1:Ntm;
for i=1:100;
M.T(i,j)     = sum(TP(i,j)+TN(i,j));
M.F(i,j)     = sum(FP(i,j)+FN(i,j));
M.TPR(i,j)   = TP(i,j)/(TP(i,j)+FN(i,j));
M.FNR(i,j)   = FN(i,j)/(TP(i,j)+FN(i,j));
M.FPR(i,j)   = FP(i,j)/(TN(i,j)+FP(i,j));
M.TNR(i,j)   = TN(i,j)/(TN(i,j)+FP(i,j));
M.PPV(i,j)   = TP(i,j)/(TP(i,j)+FP(i,j));
M.NPV(i,j)   = TN(i,j)/(TN(i,j)+FN(i,j));
M.RPP(i,j)   = (TP(i,j)+FP(i,j))/(TP(i,j)+FN(i,j)+FP(i,j)+TN(i,j));
M.RNP(i,j)   = (TN(i,j)+FN(i,j))/(TP(i,j)+FN(i,j)+FP(i,j)+TN(i,j));
M.ACC(i,j)   = (TP(i,j)+TN(i,j))/(TP(i,j)+FN(i,j)+TP(i,j)+TN(i,j));
M.MCC(i,j)   = ((TP(i,j)*TN(i,j))-(FP(i,j)*FN(i,j)))/sqrt((TP(i,j)+FP(i,j))*(TP(i,j)+FN(i,j))*(TN(i,j)+FP(i,j))*(TN(i,j)+FN(i,j)));
M.FM(i,j)=2*(((TP(i,j)/(TP(i,j)+FN(i,j)))*(TP(i,j)/(TP(i,j)+FP(i,j))))/((TP(i,j)/(TP(i,j)+FN(i,j)))+(TP(i,j)/(TP(i,j)+FP(i,j)))));

end
end
mkdir('results');
cd results;
FileName=['M.',datestr(now, 'dd-mmm-yyyy HH-MM-SS-FFF AM'),'.mat'];
save(FileName,'M');
cd ..
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
