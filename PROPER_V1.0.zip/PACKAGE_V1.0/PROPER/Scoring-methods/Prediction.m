%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% Prediction  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - Classifer : The name of the classifier
% - Method: The Validation Method
% - CVT: The type of cross-validation/data-partitioning
% - P: The labels predicted by the classifier
% - Model: The Model trained by the classifier
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% Classifier  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all  clc
%% The Name of Classifier
flag.C=0;
while(flag.C==0)
Classifier= input ('\n   Enter the name of classifier:\n    ANN for Artificial Neural Network, RLR for Regularized Logistic Regression, RF for Random Forest:   ','s');
switch Classifier
case 'ANN'
flag.C=1;
case 'RLR'
flag.C=2;
case 'RF'
flag.C=3;
otherwise
if(isempty(Classifier))
fprintf('\n   You did not enter the name of classifier! Please Try again!');
else
fprintf('\n   The name of the classifier you entered (%s) is not valid! Please Try again!', Classifier);
end
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%  Model-Validation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% The Validation Method
flag.M=0;
cd Data; 
while(flag.M==0)
Method= input('\n   Enter the validation method:\n    IND for independent validation, CV for cross validation, RESUB for Resubstitution:   ','s');
switch Method

%% Cross-validation
case 'CV'
flag.M=1;
%% The Data Set for Cross Validation
flag.D=0;
while(flag.D==0)
Data=input('\n   Enter the name of Data set (for example Sample.mat):   ','s');
if exist(Data,'file')
Trainingset=importdata(Data);
flag.D=1;
else
fprintf('\n   The filename you entered (%s) does not exist in the MATLAB Current Folder! Please Try again!\n', Data);
end
end
%% Independent-validation 
case'IND'
CVT='IND';
flag.M=2;
%% Training and Testing Sets for Independent Validation
flag.D1=0;
flag.D2=0;
while(flag.D1==0)
Data1=input('\n   Enter the name of Training set (for example Trainingset.mat):   ','s');
if exist(Data1,'file')
Trainingset=importdata(Data1);
flag.D1=1;
else
fprintf('\n   The filename you entered (%s) does not exist in the MATLAB Current Folder! Please Try again!\n', Data1);
end
end
while(flag.D2==0)
Data2=input('\n   Enter the name of Testing set (for example Testingset.mat):   ','s');
if exist(Data2,'file')
Testingset=importdata(Data2);
flag.D2=1;
else
fprintf('\n   The filename you entered (%s) does not exist in the MATLAB Current Folder! Please Try again!n', Data2);  
end
end
%% Resubstitution
case 'RESUB'
CVT='RESUB';
flag.M=3;
%% The Data set for Resubstitution
flag.D=0;
while(flag.D==0)
Data=input('\n   Enter the name of Data set (for example Sample.mat):   ','s');
if exist(Data,'file')
Trainingset=importdata(Data);
flag.D=1;
else
fprintf('\n   The filename you entered (%s) does not exist in the MATLAB Current Folder! Please Try again!\n', Data);
end
end
CVP=cvpartition(Trainingset(:,end),'resubstitution');
fprintf('\n   You chose Resubstitution validation.');
otherwise
if(isempty(Method))
fprintf('\n   You did not enter the validation method! Please Try again!');
else
fprintf('\n   The validation method you entered (%s) is not valid! Please Try again!\n', Method);
end
end
end
%% Training Data
y=Trainingset(:,end);
X=Trainingset(:,1:end-1);
cd ..
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% Cross-validation Type %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Type of Validation Partition
flag.CVT=0;
if flag.M==1
while(flag.CVT==0)
CVT=input('\n   Enter the type of validation partition:\n    K for k-fold cross validation, LOO for leave-one-out, or press ''Enter'' for default which is 5-fold cross validation:   ','s');
switch CVT
%% Leave-one-out  
case 'LOO'
CVP=cvpartition(y,'leaveout');
fprintf('\n   You chose Leave-one-out cross validation.\n');
flag.CVT=1;
%%  K-fold 
case 'K'
k=input ('\n   Enter the number of folds:   ');
if(isnumeric(k)==1 && length(k)==1)
CVP=cvpartition(y,'k',k);
fprintf('\n   You chose %d-fold cross validation.\n',k);
flag.CVT=1;
end
otherwise 
if(isempty(CVT))
k=5;
CVP=cvpartition(y,'k',k);
fprintf('\n  You chose %d-fold cross validation.\n',k);
flag.CVT=1;
else
fprintf('\n   The type of validation partition you entered (%s) is not valid! Please Try again!\n', CVT);
end
end
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% Artificial Neural Network  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Parameters for Artificial Neural Network
if (flag.C==1)
root=cd;             
addpath(genpath([root '/ANN']));
cd ANN    
fprintf('\n   In the following steps, enter the required inputs. Please consider that the large size of input will increase the processing time.\n')
%% Number of Hidden Nodes
flag.K=0;
while(flag.K==0)
k=input('\n   Enter the number of hidden nodes in form of a numeric vector, or press ''Enter'' for the default which is equal to [15]:   ');
if (isempty(k));
k=[15];
flag.K=1;
elseif(round(k)==k)
flag.K=1;
else
fprintf('\n   The input you entered for the number of hidden nodes is not a numeric vector! Please Try again!\n');    
end 
end
%% Training Algorithms
flag.G=0;
while(flag.G==0)
g=input('\n   Enter the name of training algorithms in form of a cell array, or press ''Enter'' for the default which is {''trainrp''}:   ');
if (isempty(g))
g={'trainrp'};
flag.G=1;
elseif(iscell(g))
flag.G=1;
else
fprintf('\n   The input you entered for the name of training algorithms is not a cell array! Please Try again!\n');     
end
end
%% Training Rate
flag.TR=0;
while(flag.TR==0)
Trate=input('\n   Enter training rate(s) in form of a numeric vector, or press ''Enter'' for the default which equals 0.02:   ');
if(isempty(Trate))
Trate=0.02;
flag.TR=1;
elseif(isvector(Trate) && isnumeric(Trate))
flag.TR=1;
else
fprintf('\n   The input you entered for the training rate(s) is not a numeric vector! Please Try again!\n');  
end
end
%% Number of Iterations
flag.I=0;
while(flag.I==0)
I=input ('\n   Enter the number of iterations, or press ''Enter'' for default which is equal to 200:   ');
if(isempty(I))
I=200;
flag.I=1;
elseif(round(I)==I && length(I)==1 && abs(I)==I)
flag.I=1;
else
fprintf('\n   The input you entered for the number of iterations is not a whole number! Please Try again!\n');     
end
end
%% Cross validation/Resubstitution for Artificial Neural Network
if(flag.M==1||flag.M==3)
fprintf('\n   The size of Training and Testing sets equal %d and %d, respectively.\n',CVP.TrainSize(1),CVP.TestSize(1));
for i = 1:CVP.NumTestSets
trIdx = CVP.training(i);
teIdx = CVP.test(i);
[P(teIdx,:),model]= ANN(X(trIdx,:),y(trIdx,:),X(teIdx,:),I,Trate,k,g);
if(~strcmp(CVT,'LOO')) 
Model.(sprintf('M%d',i))=model;
end
end
end
%% Independent validation for Artificial Neural Network 
if (flag.M==2)
[P,Model]=ANN(X,y,Testingset(:,1:end-1),I,Trate,k,g);
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% Regularized Logistic Regression  %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Parameters for Regularized Logistic Regression
if(flag.C==2)
root=cd;             
addpath(genpath([root '/Regularized-LR'])); % add the functions in the folder SLEP to the path
cd Regularized-LR        % set the working directory back
flag.Rho=0;
while(flag.Rho==0)
Rho=input('\n   Enter the regularization parameter in form of a numeric vector, or press ''Enter'' for the default which is [0.1 0.2 0.3 0.4]:   ');
if isempty(Rho)==1
Rho=[0.1 0.2 0.3 0.4];
flag.Rho=1;
elseif(isvector(Rho)&& isnumeric(Rho))
flag.Rho=1;
else
fprintf('\n   The value you entered for regularization parameter (%s) is not a numeric vector! Please Try again!\n', Rho);
end 
end
[~,K]=size(Rho);
[m,~]=size(y);
for i=1:m;
if y(i)==0;
y(i)=-1;
end
end
Model.Labels=y;
%----------------------- Set optional items -------------------------------
opts=[];
% Starting point
opts.init=2;        % starting from a zero point
% Termination 
opts.tFlag=5;       % run .maxIter iterations
opts.maxIter=40;    % maximum number of iterations
% Normalization
opts.nFlag=0;       % without normalization
% Regularization
opts.rFlag=1;       % the input parameter 'rho' is a ratio in (0, 1)
opts.rsL2=0.01;     % the squared two norm term
% Group Property
opts.sWeight=[1,2]; % set the weight for positive and negative samples
%--------------------------------------------------------------------------
%% Cross validation/Resubstitution for Regularized Logistic Regression
if (flag.M==1||flag.M==3)
fprintf('\n   The size of Training and Testing sets equal %d and %d, respectively.\n',CVP.TrainSize(1),CVP.TestSize(1));
for i = 1:CVP.NumTestSets
trIdx = CVP.training(i);
teIdx = CVP.test(i);
for l=1:(K);
rho=Rho(l);          % the regularization parameter which is a ratio between (0,1)
[x, c, ~]=LogisticR(X(trIdx,:), y(trIdx,:), rho, opts);
A(:,l)=x;
C(l)=c;
P(teIdx,l)=X(teIdx,:)*A(:,l)+C(l);
if(~strcmp(CVT,'LOO'))
Model.(sprintf('M%d_Weights',i))(:,l)=x;
Model.(sprintf('M%d_intercepts',i))(:,l)=c;
end
end
end
end
%% Independent validation for Regularized Logistic Regression
if (flag.M==2)
for l=1:(K);
rho=Rho(l);          % the regularization parameter which is a ratio between (0,1)
[x, c, ~]=LogisticR(X,y, rho, opts);
%A(:,l)=x;
C(l)=c;
%P(:,l)=Testingset(:,1:end-1)*A(:,l)+C(l);
P(:,l)=Testingset*x+C(l);
Model.M_Weights(:,l)=x;
Model.M_Intercep(:,l)=c;
end
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% Regression Based Random Forest  %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Parameters for Regression Based Random Forest
if (flag.C==3)
root=cd;             
addpath(genpath([root '/Randomforest']));
cd Randomforest
if strcmpi(computer,'PCWIN')||strcmpi(computer,'PCWIN64')
compile_windows
else
compile_linux
end
fprintf('\n   In the following steps, enter the required inputs. Please consider that the large size of input will increase the processing time.\n')
%% Number of trees
flag.NT=0;
while(flag.NT==0)
ntree=input('\n   Enter the number of trees, or press ''Enter'' for the default which is 500:   ');
if (isempty(ntree));
ntree=500;
flag.NT=1;
elseif(round(ntree)==ntree && length(ntree)==1)
flag.NT=1;
else
fprintf('\n   The value you entered for the number of trees is not a number! Please Try again!\n  ');
end 
end
%% Number of features
flag.MT=0;
while(flag.MT==0)
defaultMT= max(floor(size(X,2)/3),1);
fprintf('\n   Enter the number of features in Trainingset, or press ''Enter'' for the default value which is %d:   ',defaultMT);
mtry=input('');
if (isempty(mtry)); 
mtry = max(floor(size(X,2)/3),1);
flag.MT=1;
elseif(round(mtry)==mtry && length(mtry)==1)
flag.MT=1;
else
fprintf('\n   The value you entered for the number of features is not a number! Please Try again!\n');
end
end
%% Cross/Resubstitution validation for Regression based Random Forest 
if (flag.M==1||flag.M==3)
fprintf('\n   The size of Training and Testing sets equal %d and %d, respectively.\n',CVP.TrainSize(1),CVP.TestSize(1));
for i = 1:CVP.NumTestSets
trIdx = CVP.training(i);
teIdx = CVP.test(i);
model= regRF_train(X(trIdx,:),y(trIdx,:),ntree,mtry);
P(teIdx,:) = regRF_predict(X(teIdx,:),model);
if(~strcmp(CVT,'LOO'))
Model.(sprintf('M%d',i))=model;
end
end
end
%% Independent validation for Regression based Random Forest 
if (flag.M==2)
Model= regRF_train(X,y,ntree,mtry);
P= regRF_predict(Testingset(:,1:end-1),Model);
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%  Results   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mkdir('Results');
cd Results;
if( exist('P','var'))
FileName1=['P.',datestr(now, 'dd-mmm-yyyy HH-MM-SS-FFF AM'),'.mat'];
save(FileName1,'P');
fprintf('\n %s successfuly saved in %s. \n',FileName1,cd);
end
if( exist('Model','var'))
FileName2=['Model.',datestr(now, 'dd-mmm-yyyy HH-MM-SS-FFF AM'),'.mat'];
save(FileName2,'Model');
fprintf('\n %s successfuly saved in %s. \n',FileName2,cd);
end
cd ..
cd ..
